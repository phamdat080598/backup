public class People{
	private String nationality;
	
	public void showNationality(){
		System.out.println("class people show natonality");
	}
}