public class Vietnamese extends People{
	
	public void showNationality(){
		System.out.println("Natonality : Vietnamese");
	}
}